import re

def clean_text(text):
    """
    Basic text cleaning function.
    Removes special characters, converts to lowercase, and trims extra spaces.
    """
    text = text.lower()  # convert to lowercase
    text = re.sub(r'[^a-z0-9\s]', '', text)  # remove special characters
    text = re.sub(r'\s+', ' ', text).strip()  # remove extra spaces
    return text
